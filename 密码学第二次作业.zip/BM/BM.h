#ifndef BM_H
#define BM_H

void B_M(int a, int nn);

#endif