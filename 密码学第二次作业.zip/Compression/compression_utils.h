#ifndef COMPRESSION_UTILS_H
#define COMPRESSION_UTILS_H

typedef unsigned char BYTE;
typedef unsigned int WORD;

// SHA2

#define ROTLEFT(a, b) (((a) << (b)) | ((a) >> (32 - (b))))
#define ROTRIGHT(a, b) (((a) >> (b)) | ((a) << (32 - (b))))

#define CH(x, y, z) (((x) & (y)) ^ (~(x) & (z)))
#define MAJ(x, y, z) (((x) & (y)) ^ ((x) & (z)) ^ ((y) & (z)))
#define EP0(x) (ROTRIGHT(x, 2) ^ ROTRIGHT(x, 13) ^ ROTRIGHT(x, 22))
#define EP1(x) (ROTRIGHT(x, 6) ^ ROTRIGHT(x, 11) ^ ROTRIGHT(x, 25))
#define SIG0(x) (ROTRIGHT(x, 7) ^ ROTRIGHT(x, 18) ^ ((x) >> 3))
#define SIG1(x) (ROTRIGHT(x, 17) ^ ROTRIGHT(x, 19) ^ ((x) >> 10))

// SHA3
#define T(j) (j >= 0 && j < 16) ? 0x79cc4519 : 0x7a879d8a
#define FF(j, x, y, z) (j >= 0 && j < 16) ? (x ^ y ^ z) : ((x & y) | (x & z) | (y & z))
#define GG(j, x, y, z) (j >= 0 && j < 16) ? (x ^ y ^ z) : ((x & y) | ((~x)&z))
#define P0(x) x ^ (ROTLEFT(x, 9)) ^ (ROTLEFT(x, 17))
#define P1(x) x ^ (ROTLEFT(x, 15)) ^ (ROTLEFT(x, 23))

#endif